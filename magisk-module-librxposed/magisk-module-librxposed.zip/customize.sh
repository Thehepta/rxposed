ui_print "******************************"
ui_print "** magisk install mp4handle **"
ui_print "******************************"

chmod +x /system/bin/ffmpeg